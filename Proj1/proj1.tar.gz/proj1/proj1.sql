-- COMP9311 18s1 Project 1
--
-- MyMyUNSW Solution Template


-- Q1: 
create or replace view Q1(unswid, name)
as
--... SQL statements, possibly using other views/functions defined by you ...
;



-- Q2: 
create or replace view Q2(unswid, name)
as
--... SQL statements, possibly using other views/functions defined by you ...
;



-- Q3: 
create or replace view Q3(unswid, name)
as
--... SQL statements, possibly using other views/functions defined by you ...
;



-- Q4:
create or replace view Q4(unswid, name)
as
--... SQL statements, possibly using other views/functions defined by you ...
;



-- Q5: 
create or replace view Q5a(num)
as
--... SQL statements, possibly using other views/functions defined by you ...
;

-- Q5: 
create or replace view Q5b(num)
as
--... SQL statements, possibly using other views/functions defined by you ...
;


-- Q6:
create or replace function
	Q6(text) returns text
as
$$
--... SQL statements, possibly using other views/functions defined by you ...
$$ language sql;



-- Q7: 
create or replace view Q7(code, name)
as
--... SQL statements, possibly using other views/functions defined by you ...
;



-- Q8:
create or replace view Q8(code, name, semester)
as
--... SQL statements, possibly using other views/functions defined by you ...
;



-- Q9:
create or replace view Q9(name, school, email, starting, num_subjects)
as
--... SQL statements, possibly using other views/functions defined by you ...
;



-- Q10:
create or replace view Q10(code, name, year, s1_HD_rate, s2_HD_rate)
as
--... SQL statements, possibly using other views/functions defined by you ...
;